return {
  ---------------- nvim-toggleterm------------------------------
  {
    'akinsho/toggleterm.nvim',
--    config = function() 
--      require('toggleterm').setup{} 
--    end, 
--    version = "*", 
--    opts = {--[[ things you want to change go here]]
  },
  ---------------- END nvim-toggle-term------------------------------

}
