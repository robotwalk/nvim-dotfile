return {
  ---------------- nightfly colorscheme ------------------
  {
    "bluz71/vim-nightfly-guicolors",
    config = function()
    vim.cmd([[colorscheme nightfly]]) -- set this colorscheme 
    end,
  }
  ---------------- END nightfly colorscheme ------------------
}
