return{
  ---------------- nvim-lualine ------------------------------
 {
    'nvim-lualine/lualine.nvim',
    dependencies = { 'nvim-tree/nvim-web-devicons' },

 }, 
  ---------------- END nvim-lualine ------------------------------
}
