abstract public @interface Foo {
  abstract public String Bar();
}
